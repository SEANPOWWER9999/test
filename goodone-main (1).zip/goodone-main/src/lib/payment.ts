import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const generateBTCAddress = async (amount: number) => {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    
    if (!user) {
      throw new Error("You must be logged in to make a donation");
    }

    // Call the edge function to generate BTC address
    const { data, error } = await supabase.functions.invoke('generate-btc-address', {
      body: { amount }
    });

    if (error) throw error;

    // Create patron donation record
    const { error: insertError } = await supabase
      .from('patron_donations')
      .insert({
        user_id: user.id,
        amount: amount,
        reward_credit: amount * 2, // Double the donation amount as credit
        btc_address: data.address,
        status: 'pending'
      });

    if (insertError) throw insertError;

    return data;
  } catch (error: any) {
    throw new Error(error.message || "Failed to generate BTC address");
  }
};