import React from 'react';
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Welcome from "./pages/Welcome";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Profile from "./pages/Profile";
import AdminDashboard from "./pages/AdminDashboard";
import AdminLogin from "./pages/AdminLogin";
import Training from "./pages/Training";
import HotBotStory from "./pages/HotBotStory";
import Subscription from "./pages/Subscription";
import TrainerPortal from "./pages/TrainerPortal";
import TrainerDashboard from "./pages/TrainerDashboard";
import TrainerLogin from "./pages/TrainerLogin";
import Patron from "./pages/Patron";
import Analytics from "./pages/Analytics";
import Preferences from "./pages/Preferences";
import Help from "./pages/Help";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 1000,
      retry: 1,
    },
  },
});

const App = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/welcome" element={<Welcome />} />
            <Route path="/" element={<Index />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<Signup />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/login" element={<AdminLogin />} />
            <Route path="/training" element={<Training />} />
            <Route path="/story" element={<HotBotStory />} />
            <Route path="/subscription" element={<Subscription />} />
            <Route path="/trainer/portal" element={<TrainerPortal />} />
            <Route path="/trainer/dashboard" element={<TrainerDashboard />} />
            <Route path="/trainer/login" element={<TrainerLogin />} />
            <Route path="/patron" element={<Patron />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/preferences" element={<Preferences />} />
            <Route path="/help" element={<Help />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  );
};

export default App;