export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      admin_profiles: {
        Row: {
          created_at: string | null
          id: string
          is_admin: boolean | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_admin?: boolean | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_admin?: boolean | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      api_usage: {
        Row: {
          endpoint: string
          error_message: string | null
          id: string
          success: boolean | null
          timestamp: string | null
          user_id: string | null
        }
        Insert: {
          endpoint: string
          error_message?: string | null
          id?: string
          success?: boolean | null
          timestamp?: string | null
          user_id?: string | null
        }
        Update: {
          endpoint?: string
          error_message?: string | null
          id?: string
          success?: boolean | null
          timestamp?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      applications: {
        Row: {
          created_at: string | null
          description: string
          email: string
          id: string
          status: string | null
          type: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          description: string
          email: string
          id?: string
          status?: string | null
          type: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          description?: string
          email?: string
          id?: string
          status?: string | null
          type?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      btc_deposits: {
        Row: {
          amount: number
          btc_address: string
          created_at: string | null
          id: string
          status: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          btc_address: string
          created_at?: string | null
          id?: string
          status?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          btc_address?: string
          created_at?: string | null
          id?: string
          status?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string | null
          id: string
          role: string
          session_id: string | null
          timestamp: number
          updated_at: string | null
        }
        Insert: {
          content: string
          created_at?: string | null
          id?: string
          role: string
          session_id?: string | null
          timestamp: number
          updated_at?: string | null
        }
        Update: {
          content?: string
          created_at?: string | null
          id?: string
          role?: string
          session_id?: string | null
          timestamp?: number
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_session_id_fkey"
            columns: ["session_id"]
            isOneToOne: false
            referencedRelation: "chat_sessions"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_sessions: {
        Row: {
          created_at: string | null
          id: string
          is_escort_mode: boolean | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          is_escort_mode?: boolean | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          is_escort_mode?: boolean | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      chat_settings: {
        Row: {
          created_at: string | null
          id: string
          max_tokens: number | null
          repetition_penalty: number | null
          temperature: number | null
          top_p: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          max_tokens?: number | null
          repetition_penalty?: number | null
          temperature?: number | null
          top_p?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          max_tokens?: number | null
          repetition_penalty?: number | null
          temperature?: number | null
          top_p?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      conversations: {
        Row: {
          client_phone: string
          context: Json | null
          created_at: string | null
          id: string
          persona_id: string | null
          status: string | null
          updated_at: string | null
        }
        Insert: {
          client_phone: string
          context?: Json | null
          created_at?: string | null
          id?: string
          persona_id?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          client_phone?: string
          context?: Json | null
          created_at?: string | null
          id?: string
          persona_id?: string | null
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      early_bird_spots: {
        Row: {
          amount: number
          btc_address: string
          created_at: string | null
          id: string
          status: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          btc_address: string
          created_at?: string | null
          id?: string
          status?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          btc_address?: string
          created_at?: string | null
          id?: string
          status?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          content: string
          conversation_id: string | null
          created_at: string | null
          id: string
          sender_type: string
          updated_at: string | null
        }
        Insert: {
          content: string
          conversation_id?: string | null
          created_at?: string | null
          id?: string
          sender_type: string
          updated_at?: string | null
        }
        Update: {
          content?: string
          conversation_id?: string | null
          created_at?: string | null
          id?: string
          sender_type?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
        ]
      }
      patron_donations: {
        Row: {
          amount: number
          btc_address: string
          created_at: string | null
          id: string
          reward_credit: number
          status: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          amount: number
          btc_address: string
          created_at?: string | null
          id?: string
          reward_credit: number
          status?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          amount?: number
          btc_address?: string
          created_at?: string | null
          id?: string
          reward_credit?: number
          status?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      personas: {
        Row: {
          age: number | null
          avoid_words: string[] | null
          backstory: string | null
          blocked_numbers: string[] | null
          conversation_style: string | null
          created_at: string | null
          daily_usage: number | null
          formality_level: string | null
          httpsms_api_key: string | null
          httpsms_phone: string | null
          id: string
          interests: string[] | null
          is_active: boolean | null
          message_count: number | null
          name: string
          preferred_response_length: string | null
          preferred_words: string[] | null
          response_template: Json | null
          tone: string | null
          typical_phrases: string[] | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          age?: number | null
          avoid_words?: string[] | null
          backstory?: string | null
          blocked_numbers?: string[] | null
          conversation_style?: string | null
          created_at?: string | null
          daily_usage?: number | null
          formality_level?: string | null
          httpsms_api_key?: string | null
          httpsms_phone?: string | null
          id?: string
          interests?: string[] | null
          is_active?: boolean | null
          message_count?: number | null
          name: string
          preferred_response_length?: string | null
          preferred_words?: string[] | null
          response_template?: Json | null
          tone?: string | null
          typical_phrases?: string[] | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          age?: number | null
          avoid_words?: string[] | null
          backstory?: string | null
          blocked_numbers?: string[] | null
          conversation_style?: string | null
          created_at?: string | null
          daily_usage?: number | null
          formality_level?: string | null
          httpsms_api_key?: string | null
          httpsms_phone?: string | null
          id?: string
          interests?: string[] | null
          is_active?: boolean | null
          message_count?: number | null
          name?: string
          preferred_response_length?: string | null
          preferred_words?: string[] | null
          response_template?: Json | null
          tone?: string | null
          typical_phrases?: string[] | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      profile_settings: {
        Row: {
          api_enabled: boolean | null
          api_key: string | null
          chatbot_character: string | null
          chatbot_knowledge: string | null
          chatbot_style: string | null
          created_at: string | null
          daily_message_limit: number | null
          description: string | null
          id: string
          is_description_locked: boolean | null
          is_rates_locked: boolean | null
          is_services_locked: boolean | null
          message_count: number | null
          rates: Json | null
          services: Database["public"]["Enums"]["service_type"][] | null
          status: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          api_enabled?: boolean | null
          api_key?: string | null
          chatbot_character?: string | null
          chatbot_knowledge?: string | null
          chatbot_style?: string | null
          created_at?: string | null
          daily_message_limit?: number | null
          description?: string | null
          id?: string
          is_description_locked?: boolean | null
          is_rates_locked?: boolean | null
          is_services_locked?: boolean | null
          message_count?: number | null
          rates?: Json | null
          services?: Database["public"]["Enums"]["service_type"][] | null
          status?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          api_enabled?: boolean | null
          api_key?: string | null
          chatbot_character?: string | null
          chatbot_knowledge?: string | null
          chatbot_style?: string | null
          created_at?: string | null
          daily_message_limit?: number | null
          description?: string | null
          id?: string
          is_description_locked?: boolean | null
          is_rates_locked?: boolean | null
          is_services_locked?: boolean | null
          message_count?: number | null
          rates?: Json | null
          services?: Database["public"]["Enums"]["service_type"][] | null
          status?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      saved_codes: {
        Row: {
          code: string
          created_at: string | null
          id: string
          language: string
          title: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          code: string
          created_at?: string | null
          id?: string
          language: string
          title: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          code?: string
          created_at?: string | null
          id?: string
          language?: string
          title?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      sms_logs: {
        Row: {
          created_at: string | null
          direction: string | null
          id: string
          message_text: string
          message_type: string | null
          phone_number: string
          timestamp: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string | null
          direction?: string | null
          id?: string
          message_text: string
          message_type?: string | null
          phone_number: string
          timestamp?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string | null
          direction?: string | null
          id?: string
          message_text?: string
          message_type?: string | null
          phone_number?: string
          timestamp?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      trainer_applications: {
        Row: {
          created_at: string | null
          email: string
          experience: string
          id: string
          specialization: string
          status: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          email: string
          experience: string
          id?: string
          specialization: string
          status?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          email?: string
          experience?: string
          id?: string
          specialization?: string
          status?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
      training_sessions: {
        Row: {
          created_at: string | null
          feedback: string | null
          id: string
          is_correct: boolean | null
          model_type: Database["public"]["Enums"]["model_type"]
          prompt: string
          response: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          feedback?: string | null
          id?: string
          is_correct?: boolean | null
          model_type: Database["public"]["Enums"]["model_type"]
          prompt: string
          response: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          feedback?: string | null
          id?: string
          is_correct?: boolean | null
          model_type?: Database["public"]["Enums"]["model_type"]
          prompt?: string
          response?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      user_settings: {
        Row: {
          api_key: string
          created_at: string | null
          custom_webhook_url: string | null
          id: string
          phone_number: string | null
          sip_region: string | null
          sip_subdomain: string | null
          updated_at: string | null
          user_id: string
          webhook_events: string[] | null
          webhook_url: string | null
        }
        Insert: {
          api_key?: string
          created_at?: string | null
          custom_webhook_url?: string | null
          id?: string
          phone_number?: string | null
          sip_region?: string | null
          sip_subdomain?: string | null
          updated_at?: string | null
          user_id: string
          webhook_events?: string[] | null
          webhook_url?: string | null
        }
        Update: {
          api_key?: string
          created_at?: string | null
          custom_webhook_url?: string | null
          id?: string
          phone_number?: string | null
          sip_region?: string | null
          sip_subdomain?: string | null
          updated_at?: string | null
          user_id?: string
          webhook_events?: string[] | null
          webhook_url?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      model_type: "gpt-4o" | "gpt-4o-mini"
      service_type:
        | "Travel"
        | "Dinner"
        | "Intimacy"
        | "Companionship"
        | "Fetish"
        | "BDSM"
        | "GFE"
        | "Role-play"
        | "Massage"
        | "Conversation"
        | "Dancing"
        | "Couples"
        | "Overnight"
        | "Fitness"
        | "Virtual"
        | "Party"
        | "Weekend"
        | "Shopping"
        | "Concerts"
        | "Outdoors"
        | "Wine"
        | "Culture"
        | "Education"
        | "Photography"
        | "Cooking"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type PublicSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  PublicTableNameOrOptions extends
    | keyof (PublicSchema["Tables"] & PublicSchema["Views"])
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
        Database[PublicTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? (Database[PublicTableNameOrOptions["schema"]]["Tables"] &
      Database[PublicTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : PublicTableNameOrOptions extends keyof (PublicSchema["Tables"] &
        PublicSchema["Views"])
    ? (PublicSchema["Tables"] &
        PublicSchema["Views"])[PublicTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  PublicTableNameOrOptions extends
    | keyof PublicSchema["Tables"]
    | { schema: keyof Database },
  TableName extends PublicTableNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = PublicTableNameOrOptions extends { schema: keyof Database }
  ? Database[PublicTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : PublicTableNameOrOptions extends keyof PublicSchema["Tables"]
    ? PublicSchema["Tables"][PublicTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  PublicEnumNameOrOptions extends
    | keyof PublicSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends PublicEnumNameOrOptions extends { schema: keyof Database }
    ? keyof Database[PublicEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = PublicEnumNameOrOptions extends { schema: keyof Database }
  ? Database[PublicEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : PublicEnumNameOrOptions extends keyof PublicSchema["Enums"]
    ? PublicSchema["Enums"][PublicEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof PublicSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof PublicSchema["CompositeTypes"]
    ? PublicSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never
