export type ServiceType = 
  | "Travel" | "Dinner" | "Intimacy" | "Companionship" 
  | "Fetish" | "BDSM" | "GFE" | "Role-play" | "Massage" 
  | "Conversation" | "Dancing" | "Couples" | "Overnight"
  | "Fitness" | "Virtual" | "Party" | "Weekend" | "Shopping" 
  | "Concerts" | "Outdoors" | "Wine" | "Culture" | "Education" 
  | "Photography" | "Cooking";

export interface ProfileRates {
  "30min": { incall: string | null; outcall: string | null };
  "1hour": { incall: string | null; outcall: string | null };
  overnight: { incall: string | null; outcall: string | null };
}

export interface ProfileState {
  status: string;
  description: string;
  rates: ProfileRates;
  services: ServiceType[];
  is_description_locked: boolean;
  is_rates_locked: boolean;
  is_services_locked: boolean;
  chatbot_character: string;
  chatbot_knowledge: string;
  chatbot_style: string;
}

export interface ProfileSettings extends ProfileState {
  id: string;
  created_at?: string;
  updated_at?: string;
}