import { Json, ServiceType } from './base';

export interface TableRow<T extends { [key: string]: any }> {
  Row: T;
  Insert: Partial<T> & Required<Pick<T, 'user_id'>>;
  Update: Partial<T>;
  Relationships: [];
}

export interface Tables {
  admin_profiles: TableRow<{
    id: string;
    user_id: string;
    is_admin: boolean;
    created_at: string;
    updated_at: string;
  }>;

  applications: TableRow<{
    id: string;
    type: string;
    email: string;
    description: string;
    status: string;
    created_at: string;
    updated_at: string;
  }>;

  btc_deposits: TableRow<{
    id: string;
    user_id: string;
    btc_address: string;
    amount: number;
    status: string;
    created_at: string;
    updated_at: string;
  }>;

  patron_donations: TableRow<{
    id: string;
    user_id: string;
    amount: number;
    reward_credit: number;
    status: string;
    btc_address: string;
    created_at: string;
    updated_at: string;
  }>;

  profile_settings: TableRow<{
    id: string;
    user_id: string;
    status: string;
    description: string;
    rates: Json;
    services: ServiceType[];
    is_description_locked: boolean;
    is_rates_locked: boolean;
    is_services_locked: boolean;
    chatbot_character: string;
    chatbot_knowledge: string;
    chatbot_style: string;
    created_at: string;
    updated_at: string;
  }>;

  personas: TableRow<{
    id: string;
    user_id: string;
    name: string;
    age: number | null;
    backstory: string | null;
    interests: string[] | null;
    avoid_words: string[] | null;
    preferred_words: string[] | null;
    typical_phrases: string[] | null;
    tone: string | null;
    formality_level: string | null;
    conversation_style: string | null;
    preferred_response_length: string | null;
    blocked_numbers: string[] | null;
    httpsms_api_key: string | null;
    httpsms_phone: string | null;
    message_count: number;
    created_at: string;
    updated_at: string;
  }>;

  conversations: TableRow<{
    id: string;
    client_phone: string;
    persona_id: string | null;
    context: Json | null;
    status: string;
    created_at: string;
    updated_at: string;
  }>;

  messages: TableRow<{
    id: string;
    conversation_id: string;
    content: string;
    sender_type: string;
    created_at: string;
    updated_at: string;
  }>;

  user_settings: TableRow<{
    id: string;
    user_id: string;
    api_key: string;
    phone_number: string | null;
    webhook_url: string | null;
    custom_webhook_url: string | null;
    webhook_events: string[] | null;
    created_at: string;
    updated_at: string;
  }>;

  early_bird_spots: TableRow<{
    id: string;
    user_id: string;
    amount: number;
    status: string;
    btc_address: string;
    created_at: string;
    updated_at: string;
  }>;

  saved_codes: TableRow<{
    id: string;
    user_id: string;
    title: string;
    code: string;
    language: string;
    created_at: string;
    updated_at: string;
  }>;
}
