export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type ServiceType =
  | "Travel"
  | "Dinner"
  | "Intimacy"
  | "Companionship"
  | "Fetish"
  | "BDSM"
  | "GFE"
  | "Role-play"
  | "Massage"
  | "Conversation"
  | "Dancing"
  | "Couples"
  | "Overnight"
  | "Fitness"
  | "Virtual"
  | "Party"
  | "Weekend"
  | "Shopping"
  | "Concerts"
  | "Outdoors"
  | "Wine"
  | "Culture"
  | "Education"
  | "Photography"
  | "Cooking"