import { Tables } from './tables';
import { ServiceType } from './base';

export interface Database {
  public: {
    Tables: Tables;
    Views: {};
    Functions: {};
    Enums: {
      service_type: ServiceType;
    };
    CompositeTypes: {};
  };
}

export type { Tables };
export * from './base';