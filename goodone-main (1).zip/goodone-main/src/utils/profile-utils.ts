import { ProfileRates, ServiceType } from "@/types/profileTypes";
import { Json } from "@/integrations/supabase/types/base";

const AVAILABLE_SERVICES = [
  'Travel', 'Dinner', 'Intimacy', 'Companionship', 'Fetish', 'BDSM', 'GFE',
  'Role-play', 'Massage', 'Conversation', 'Dancing', 'Couples', 'Overnight',
  'Fitness', 'Virtual', 'Party', 'Weekend', 'Shopping', 'Concerts', 'Outdoors',
  'Wine', 'Culture', 'Education', 'Photography', 'Cooking'
] as const;

export const parseRates = (data: Json | null): ProfileRates => {
  const defaultRates: ProfileRates = {
    "30min": { incall: null, outcall: null },
    "1hour": { incall: null, outcall: null },
    overnight: { incall: null, outcall: null }
  };

  if (!data || typeof data !== 'object') {
    return defaultRates;
  }

  try {
    const parsed = data as Record<string, { incall: string | null; outcall: string | null }>;
    return {
      "30min": parsed["30min"] || defaultRates["30min"],
      "1hour": parsed["1hour"] || defaultRates["1hour"],
      overnight: parsed.overnight || defaultRates.overnight
    };
  } catch {
    return defaultRates;
  }
};

export const parseServices = (services: unknown): ServiceType[] => {
  if (!Array.isArray(services)) return [];
  return services.filter((service): service is ServiceType => 
    AVAILABLE_SERVICES.includes(service as ServiceType)
  );
};