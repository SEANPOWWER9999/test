import { useState } from "react";
import { ChatMessage, ChatSettings, UserData } from "@/types/chat";

const defaultSettings: ChatSettings = {
  temperature: 0.1,
  maxTokens: 256,
  topP: 0.9,
  repetitionPenalty: 1.2
};

const defaultRates = {
  incall: {
    fifteenMin: "",
    thirtyMin: "",
    oneHour: "",
    twentyFourHours: ""
  },
  outcall: {
    fifteenMin: "",
    thirtyMin: "",
    oneHour: "",
    twentyFourHours: ""
  }
};

const defaultPersona = {
  name: "",
  description: "",
  style: "",
  preferences: "",
};

export const useChatState = () => {
  const [isEscortMode, setIsEscortMode] = useState(true);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [settings, setSettings] = useState<ChatSettings>(defaultSettings);
  const [userData, setUserData] = useState<UserData>({
    name: "",
    city: "",
    servicesOffered: "",
    rates: defaultRates,
    availability: "unavailable",
    callType: "both",
    incallLocation: "",
    outcallArea: "",
    defaultPersona: defaultPersona,
  });

  const handleUserDataChange = (field: string, value: any) => {
    setUserData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleRoleToggle = () => {
    setIsEscortMode(!isEscortMode);
  };

  return {
    isEscortMode,
    messages,
    settings,
    userData,
    setMessages,
    handleUserDataChange,
    handleRoleToggle
  };
};