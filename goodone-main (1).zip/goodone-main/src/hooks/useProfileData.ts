import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/components/ui/use-toast";
import { ProfileSettings } from "@/types/profileTypes";

export const useProfileData = (id: string | undefined) => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [profile, setProfile] = useState<ProfileSettings | null>(null);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!id) {
        setIsLoading(false);
        setError("No profile ID provided");
        return;
      }
      
      try {
        const { data, error: supabaseError } = await supabase
          .from('profile_settings')
          .select('*')
          .eq('id', id)
          .single();

        if (supabaseError) {
          throw supabaseError;
        }

        if (!data) {
          throw new Error("Profile not found");
        }

        setProfile(data as unknown as ProfileSettings);
        setError(null);
      } catch (error) {
        console.error('Error fetching profile:', error);
        setError(error instanceof Error ? error.message : "Failed to load profile");
        toast({
          title: "Error",
          description: error instanceof Error ? error.message : "Failed to load profile",
          variant: "destructive",
        });
      } finally {
        setIsLoading(false);
      }
    };

    fetchProfile();
  }, [id, toast]);

  return { profile, setProfile, isLoading, error };
};