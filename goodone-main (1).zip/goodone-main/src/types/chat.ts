export type Role = "escort" | "client";

export interface ChatMessage {
  role: Role;
  content: string;
  timestamp: number;
}

export interface ChatSettings {
  temperature: number;
  maxTokens: number;
  topP: number;
  repetitionPenalty: number;
}

export interface Rates {
  incall: {
    fifteenMin: string;
    thirtyMin: string;
    oneHour: string;
    twentyFourHours: string;
  };
  outcall: {
    fifteenMin: string;
    thirtyMin: string;
    oneHour: string;
    twentyFourHours: string;
  };
}

export interface Persona {
  name: string;
  description: string;
  style: string;
  preferences: string;
}

export interface UserData {
  name: string;
  city: string;
  servicesOffered: string;
  rates: Rates;
  availability: string;
  callType: string;
  incallLocation: string;
  outcallArea: string;
  defaultPersona: Persona;
}