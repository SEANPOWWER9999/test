import { Json, ServiceType } from '@/integrations/supabase/types/base';

export type { ServiceType };

export interface ProfileRates {
  "30min": { incall: string | null; outcall: string | null };
  "1hour": { incall: string | null; outcall: string | null };
  overnight: { incall: string | null; outcall: string | null };
}

export interface ProfileState {
  status: string;
  description: string;
  rates: ProfileRates;
  services: ServiceType[];
  is_description_locked: boolean;
  is_rates_locked: boolean;
  is_services_locked: boolean;
  chatbot_character: string;
  chatbot_knowledge: string;
  chatbot_style: string;
}

export interface ProfileSettings extends ProfileState {
  id: string;
  created_at?: string;
  updated_at?: string;
}