import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { UserData } from "@/types/chat";

interface UserSettingsProps {
  userData: UserData;
  onUserDataChange: (field: string, value: any) => void;
}

const UserSettings = ({ userData, onUserDataChange }: UserSettingsProps) => {
  return (
    <Card className="p-6 space-y-4">
      <h2 className="text-xl font-semibold">User Settings</h2>
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            value={userData.name}
            onChange={(e) => onUserDataChange("name", e.target.value)}
            placeholder="Your name"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="city">City</Label>
          <Input
            id="city"
            value={userData.city}
            onChange={(e) => onUserDataChange("city", e.target.value)}
            placeholder="Your city"
          />
        </div>
      </div>
    </Card>
  );
};

export default UserSettings;