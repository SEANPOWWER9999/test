import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { BotConfigSection } from "./BotConfigSection";
import { PersonaSection } from "./PersonaSection";
import { Button } from "@/components/ui/button";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

export const ProfileSetup = () => {
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  
  const [botConfig, setBotConfig] = useState({
    temperature: 0.1,
    maxTokens: 256,
    topP: 0.9,
    repetitionPenalty: 1.2
  });

  const [persona, setPersona] = useState({
    name: "",
    description: "",
    style: "",
    preferences: ""
  });

  const handleSave = async () => {
    try {
      setIsLoading(true);
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) throw new Error("Not authenticated");

      // Save chat settings
      const { error: settingsError } = await supabase
        .from('chat_settings')
        .upsert({
          user_id: user.id,
          temperature: botConfig.temperature,
          max_tokens: botConfig.maxTokens,
          top_p: botConfig.topP,
          repetition_penalty: botConfig.repetitionPenalty
        });

      if (settingsError) throw settingsError;

      // Save persona
      const { error: personaError } = await supabase
        .from('personas')
        .upsert({
          user_id: user.id,
          name: persona.name,
          backstory: persona.description,
          conversation_style: persona.style,
          interests: [persona.preferences],
          is_active: true
        });

      if (personaError) throw personaError;

      toast({
        title: "Success",
        description: "Bot settings saved successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-8">
      <Accordion type="single" collapsible className="mb-6">
        <AccordionItem value="bot-info">
          <AccordionTrigger className="text-lg font-semibold text-pink-600">
            About Amber Bot Settings
          </AccordionTrigger>
          <AccordionContent className="space-y-4 text-gray-600">
            <div>
              <h3 className="font-semibold text-pink-500 mb-2">Persona Settings</h3>
              <p>The bot uses a persona system that defines how it behaves and responds.</p>
            </div>
            
            <div>
              <h3 className="font-semibold text-pink-500 mb-2">Chat Configuration</h3>
              <p>The system uses Hugging Face's Mixtral-8x7B-Instruct model with these default settings:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>Temperature: 0.1 (Controls response randomness)</li>
                <li>Max Tokens: 256 (Limits response length)</li>
                <li>Top P: 0.9 (Controls response diversity)</li>
                <li>Repetition Penalty: 1.2 (Prevents repetitive responses)</li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold text-pink-500 mb-2">Message Handling</h3>
              <p>All messages are stored securely with role, content, timestamp, and session information.</p>
            </div>

            <div>
              <h3 className="font-semibold text-pink-500 mb-2">How It Works</h3>
              <p>The bot will automatically use your profile information to personalize responses and maintain conversation context through chat history.</p>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <PersonaSection 
        persona={persona}
        onPersonaChange={setPersona}
      />

      <BotConfigSection 
        onConfigChange={setBotConfig}
      />

      <Button 
        onClick={handleSave}
        disabled={isLoading}
        className="w-full bg-gradient-to-r from-pink-500 to-purple-500 text-white"
      >
        {isLoading ? "Saving..." : "Save Bot Settings"}
      </Button>
    </div>
  );
};