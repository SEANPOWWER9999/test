import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";

interface PersonaProps {
  onPersonaChange: (persona: {
    name: string;
    description: string;
    style: string;
    preferences: string;
  }) => void;
  persona: {
    name: string;
    description: string;
    style: string;
    preferences: string;
  };
}

export const PersonaSection = ({ onPersonaChange, persona }: PersonaProps) => {
  return (
    <Card className="p-6 space-y-6">
      <h3 className="text-lg font-semibold">Persona Settings</h3>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="name">Name</Label>
          <Input
            id="name"
            value={persona.name}
            onChange={(e) => onPersonaChange({ ...persona, name: e.target.value })}
            placeholder="Bot's identity"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description</Label>
          <Textarea
            id="description"
            value={persona.description}
            onChange={(e) => onPersonaChange({ ...persona, description: e.target.value })}
            placeholder="Details about the bot's character"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="style">Communication Style</Label>
          <Input
            id="style"
            value={persona.style}
            onChange={(e) => onPersonaChange({ ...persona, style: e.target.value })}
            placeholder="How the bot communicates"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="preferences">Preferences</Label>
          <Textarea
            id="preferences"
            value={persona.preferences}
            onChange={(e) => onPersonaChange({ ...persona, preferences: e.target.value })}
            placeholder="Specific topics or ways of interacting"
          />
        </div>
      </div>
    </Card>
  );
};