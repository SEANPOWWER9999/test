import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { StatusToggle } from "@/components/profile/StatusToggle";
import { RatesSection } from "@/components/profile/RatesSection";
import { ServicesSection } from "@/components/profile/ServicesSection";
import { ChatbotConfig } from "@/components/profile/ChatbotConfig";
import { ProfileState, ServiceType } from "@/types/profileTypes";

interface ProfileFormProps {
  profile: ProfileState;
  onSave: (profile: ProfileState) => void;
  onBack: () => void;
}

export const ProfileForm = ({ profile, onSave, onBack }: ProfileFormProps) => {
  const [currentProfile, setCurrentProfile] = useState<ProfileState>(profile);

  return (
    <div className="space-y-8">
      <div className="space-y-4">
        <h2 className="text-lg font-semibold bordered-title">Current Status</h2>
        <StatusToggle
          status={currentProfile.status}
          onStatusChange={(status) => setCurrentProfile({ ...currentProfile, status })}
        />
      </div>

      <div className="space-y-4">
        <h2 className="text-lg font-semibold bordered-title">Description</h2>
        <Textarea
          value={currentProfile.description}
          onChange={(e) => setCurrentProfile({ ...currentProfile, description: e.target.value })}
          disabled={currentProfile.is_description_locked}
          className="bg-pink-50"
          rows={4}
        />
        <div className="flex items-center space-x-2">
          <Checkbox
            id="lock-description"
            checked={currentProfile.is_description_locked}
            onCheckedChange={(checked) => 
              setCurrentProfile({ ...currentProfile, is_description_locked: checked as boolean })
            }
          />
          <Label htmlFor="lock-description">Lock Description</Label>
        </div>
      </div>

      <RatesSection
        rates={currentProfile.rates}
        isLocked={currentProfile.is_rates_locked}
        onRatesChange={(rates) => setCurrentProfile({ ...currentProfile, rates })}
        onLockChange={(locked) => setCurrentProfile({ ...currentProfile, is_rates_locked: locked })}
      />

      <ServicesSection
        selectedServices={currentProfile.services as ServiceType[]}
        isLocked={currentProfile.is_services_locked}
        onServicesChange={(services) => setCurrentProfile({ ...currentProfile, services: services as ServiceType[] })}
        onLockChange={(locked) => setCurrentProfile({ ...currentProfile, is_services_locked: locked })}
      />

      <ChatbotConfig
        character={currentProfile.chatbot_character}
        knowledge={currentProfile.chatbot_knowledge}
        style={currentProfile.chatbot_style}
        onConfigChange={({ character, knowledge, style }) => 
          setCurrentProfile({ 
            ...currentProfile, 
            chatbot_character: character,
            chatbot_knowledge: knowledge,
            chatbot_style: style
          })
        }
      />

      <div className="flex justify-between pt-4">
        <Button
          variant="outline"
          onClick={onBack}
          className="bg-pink-200 text-gray-900"
        >
          Back
        </Button>
        <Button
          onClick={() => onSave(currentProfile)}
          className="bg-pink-500 text-white hover:bg-pink-600"
        >
          Save Profile
        </Button>
      </div>
    </div>
  );
};