import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { useState } from "react";

interface BotConfigProps {
  onConfigChange: (config: {
    temperature: number;
    maxTokens: number;
    topP: number;
    repetitionPenalty: number;
  }) => void;
}

export const BotConfigSection = ({ onConfigChange }: BotConfigProps) => {
  const [config, setConfig] = useState({
    temperature: 0.1,
    maxTokens: 256,
    topP: 0.9,
    repetitionPenalty: 1.2
  });

  const handleChange = (key: string, value: number) => {
    const newConfig = { ...config, [key]: value };
    setConfig(newConfig);
    onConfigChange(newConfig);
  };

  return (
    <Card className="p-6 space-y-6">
      <h3 className="text-lg font-semibold">Bot Configuration</h3>
      
      <div className="space-y-4">
        <div className="space-y-2">
          <Label>Temperature ({config.temperature})</Label>
          <Slider
            value={[config.temperature]}
            min={0}
            max={1}
            step={0.1}
            onValueChange={([value]) => handleChange("temperature", value)}
          />
        </div>

        <div className="space-y-2">
          <Label>Max Tokens ({config.maxTokens})</Label>
          <Slider
            value={[config.maxTokens]}
            min={64}
            max={512}
            step={32}
            onValueChange={([value]) => handleChange("maxTokens", value)}
          />
        </div>

        <div className="space-y-2">
          <Label>Top P ({config.topP})</Label>
          <Slider
            value={[config.topP]}
            min={0}
            max={1}
            step={0.1}
            onValueChange={([value]) => handleChange("topP", value)}
          />
        </div>

        <div className="space-y-2">
          <Label>Repetition Penalty ({config.repetitionPenalty})</Label>
          <Slider
            value={[config.repetitionPenalty]}
            min={1}
            max={2}
            step={0.1}
            onValueChange={([value]) => handleChange("repetitionPenalty", value)}
          />
        </div>
      </div>
    </Card>
  );
};