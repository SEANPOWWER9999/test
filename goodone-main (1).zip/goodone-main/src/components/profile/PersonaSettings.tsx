import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

export const PersonaSettings = () => {
  const [name, setName] = useState("");
  const [tone, setTone] = useState("");
  const [typicalPhrases, setTypicalPhrases] = useState("");
  const { toast } = useToast();

  const handleSave = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Not authenticated");

      const { error } = await supabase
        .from('personas')
        .upsert({
          user_id: user.id,
          name,
          tone,
          typical_phrases: typicalPhrases.split('\n').filter(p => p.trim()),
          is_active: true
        });

      if (error) throw error;

      toast({
        title: "Success",
        description: "Persona settings saved successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error saving persona",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <Card className="bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-hotbot-purple">Persona Settings</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium">Name</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter persona name"
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Tone</label>
          <Input
            value={tone}
            onChange={(e) => setTone(e.target.value)}
            placeholder="e.g., Professional, Casual, Friendly"
            className="mt-1"
          />
        </div>
        <div>
          <label className="text-sm font-medium">Typical Phrases (one per line)</label>
          <Textarea
            value={typicalPhrases}
            onChange={(e) => setTypicalPhrases(e.target.value)}
            placeholder="Enter typical phrases..."
            className="mt-1"
            rows={4}
          />
        </div>
        <Button onClick={handleSave} className="w-full bg-hotbot-pink hover:bg-hotbot-purple">
          Save Persona Settings
        </Button>
      </CardContent>
    </Card>
  );
};