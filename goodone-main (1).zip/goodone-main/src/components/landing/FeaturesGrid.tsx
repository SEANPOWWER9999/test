import { MessageCircle, Shield, Sparkles, Heart } from "lucide-react";
import { motion } from "framer-motion";

export const FeaturesGrid = () => (
  <section className="py-12 px-4">
    <div className="container mx-auto">
      <motion.h2
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="text-3xl font-bold text-center mb-8 bg-gradient-to-r from-pink-500 to-purple-600 bg-clip-text text-transparent"
      >
        Why Choose The HOTBOT
      </motion.h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          {
            icon: MessageCircle,
            title: "Save Time",
            description: "Automate client interactions!"
          },
          {
            icon: Shield,
            title: "Fast & Accurate",
            description: "Quick, spot-on responses!"
          },
          {
            icon: Sparkles,
            title: "Efficient",
            description: "Handle bookings like a pro!"
          },
          {
            icon: Heart,
            title: "Personal",
            description: "Keep it real & personal!"
          }
        ].map((feature, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: index * 0.1 }}
            whileHover={{ y: -5 }}
            className="bg-white p-4 rounded-xl shadow-lg text-center group hover:shadow-xl transition-all duration-300
                     border-2 border-pink-100"
          >
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="w-12 h-12 mx-auto mb-3 bg-gradient-to-r from-hotbot-pink to-hotbot-purple rounded-full 
                       flex items-center justify-center text-white border border-white/20"
            >
              <feature.icon className="w-6 h-6" />
            </motion.div>
            <h3 className="text-lg font-bold mb-1 bg-gradient-to-r from-hotbot-pink to-hotbot-purple 
                        bg-clip-text text-transparent">{feature.title}</h3>
            <p className="text-sm text-gray-600">{feature.description}</p>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);