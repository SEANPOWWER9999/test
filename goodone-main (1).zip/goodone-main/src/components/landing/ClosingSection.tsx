import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { Crown, Users, Sparkles } from "lucide-react";

export const ClosingSection = () => {
  return (
    <section className="py-16 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="max-w-4xl mx-auto"
      >
        <motion.div
          whileHover={{ scale: 1.05 }}
          className="mt-12 text-center space-y-6"
        >
          <Link to="/signup">
            <Button className="bg-gradient-to-r from-hotbot-pink to-hotbot-purple text-white px-8 py-3 rounded-full text-lg">
              Sign Up Now
            </Button>
          </Link>
        </motion.div>

        {/* Want to Join Our Team Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mt-24 text-center space-y-8 bg-gradient-to-br from-pink-50 to-purple-50 p-12 rounded-3xl shadow-lg"
        >
          <h2 className="text-4xl font-bold bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
            Want to Join Our Team?
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto text-lg">
            We're looking for passionate individuals to help shape the future of AI communication.
            Whether you're a bot trainer, investor, or early adopter, there's a place for you!
          </p>
          <div className="flex flex-wrap justify-center gap-6 mt-8">
            <Button
              className="bg-white border-2 border-hotbot-pink text-hotbot-pink hover:bg-hotbot-pink hover:text-white
                       px-8 py-3 rounded-full flex items-center gap-3 transition-all duration-300 text-lg"
            >
              <Users className="w-5 h-5" />
              Join as Trainer
            </Button>
            <Button
              className="bg-white border-2 border-hotbot-purple text-hotbot-purple hover:bg-hotbot-purple hover:text-white
                       px-8 py-3 rounded-full flex items-center gap-3 transition-all duration-300 text-lg"
            >
              <Crown className="w-5 h-5" />
              Become an Investor
            </Button>
            <Button
              className="bg-white border-2 border-hotbot-gold text-hotbot-gold hover:bg-hotbot-gold hover:text-white
                       px-8 py-3 rounded-full flex items-center gap-3 transition-all duration-300 text-lg"
            >
              <Sparkles className="w-5 h-5" />
              Early Bird Access
            </Button>
          </div>
        </motion.div>
      </motion.div>
    </section>
  );
};