import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Sparkles, Star, Heart } from "lucide-react";

export const HeroSection = () => (
  <main className="min-h-[80vh] bg-gradient-to-br from-hotbot-pink via-hotbot-purple to-hotbot-coral pt-16 pb-8 px-4 relative overflow-hidden">
    <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158')] bg-cover bg-center opacity-10" />
    
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
      className="container mx-auto text-center max-w-4xl relative z-10"
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="mb-8 space-y-4"
      >
        <h1 className="text-3xl sm:text-4xl md:text-6xl font-bold leading-tight mb-4">
          Time to Shine,{" "}
          <span className="bg-gradient-to-r from-hotbot-yellow to-hotbot-gold bg-clip-text text-transparent">
            Gorgeous!
          </span>
        </h1>
        
        <p className="text-base sm:text-lg md:text-xl text-white/90 max-w-2xl mx-auto mb-6">
          Let <span className="font-bold text-hotbot-yellow">The HOTBOT</span> handle your messages while you focus on what matters! 💖
        </p>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
          {[
            {
              icon: Star,
              title: "Save Time ⏰",
              description: "Automate boring convos"
            },
            {
              icon: Heart,
              title: "Fast & Accurate ⚡",
              description: "Quick, spot-on replies"
            },
            {
              icon: Sparkles,
              title: "Smart Management 👑",
              description: "Handle bookings like a pro"
            },
            {
              icon: Heart,
              title: "Personal Touch 💝",
              description: "Keep it real & fun"
            }
          ].map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white/10 backdrop-blur-sm p-4 rounded-xl border border-white/20
                       hover:bg-white/20 transition-all duration-300"
            >
              <feature.icon className="w-8 h-8 text-hotbot-yellow mb-2 mx-auto" />
              <h3 className="text-sm font-bold mb-1 text-white">{feature.title}</h3>
              <p className="text-xs text-white/90">{feature.description}</p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
          className="flex flex-col sm:flex-row justify-center items-center gap-4 mt-8"
        >
          <Link to="/signup" className="w-full sm:w-auto">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full bg-white text-hotbot-pink font-bold py-3 px-6 rounded-xl
                       shadow-android hover:shadow-lg transition-all duration-300 
                       flex items-center justify-center gap-2 group
                       border-2 border-white/50"
            >
              <span>Get Started Now</span>
              <Star className="w-4 h-4 group-hover:rotate-180 transition-transform duration-300" />
            </motion.button>
          </Link>
          
          <Link to="/login" className="w-full sm:w-auto">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="w-full border-2 border-white/50 backdrop-blur-sm text-white font-bold 
                       py-3 px-6 rounded-xl transition-all duration-300 group
                       hover:border-white hover:bg-white/10"
            >
              <span>Sign In</span>
            </motion.button>
          </Link>
        </motion.div>
      </motion.div>
    </motion.div>
  </main>
);