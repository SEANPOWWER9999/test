import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

export const AddTrainerForm = () => {
  const [email, setEmail] = useState("");
  const [experience, setExperience] = useState("");
  const [specialization, setSpecialization] = useState("");
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const { error } = await supabase
      .from('applications')
      .insert([
        {
          type: 'trainer',
          email,
          description: experience,
          status: 'pending'
        }
      ]);

    if (error) {
      toast({
        title: "Error submitting application",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Application submitted",
      description: "The trainer application has been submitted successfully",
    });

    // Reset form
    setEmail("");
    setExperience("");
    setSpecialization("");
  };

  return (
    <form onSubmit={handleSubmit} className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <h2 className="text-xl font-bold mb-6 bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
        Add New Trainer
      </h2>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <Input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="w-full"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Specialization
          </label>
          <Input
            value={specialization}
            onChange={(e) => setSpecialization(e.target.value)}
            className="w-full"
            required
          />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Experience
          </label>
          <Textarea
            value={experience}
            onChange={(e) => setExperience(e.target.value)}
            className="w-full"
            rows={4}
            required
          />
        </div>
        <Button
          type="submit"
          className="w-full bg-gradient-to-r from-hotbot-pink to-hotbot-purple text-white"
        >
          Submit Application
        </Button>
      </div>
    </form>
  );
};