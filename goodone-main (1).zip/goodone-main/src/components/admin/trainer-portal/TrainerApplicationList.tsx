import { useState, useEffect } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

type TrainerApplication = {
  id: string;
  email: string;
  type: string;
  description: string;
  status: string;
  created_at: string;
};

export const TrainerApplicationList = () => {
  const [applications, setApplications] = useState<TrainerApplication[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    fetchApplications();
  }, []);

  const fetchApplications = async () => {
    const { data, error } = await supabase
      .from('applications')
      .select('*')
      .eq('type', 'trainer')
      .order('created_at', { ascending: false });

    if (error) {
      toast({
        title: "Error fetching applications",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    setApplications(data || []);
  };

  const updateApplicationStatus = async (id: string, status: string) => {
    const { error } = await supabase
      .from('applications')
      .update({ status })
      .eq('id', id);

    if (error) {
      toast({
        title: "Error updating status",
        description: error.message,
        variant: "destructive",
      });
      return;
    }

    toast({
      title: "Status updated",
      description: `Application ${status} successfully`,
    });
    fetchApplications();
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <h2 className="text-xl font-bold mb-6 bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
        Trainer Applications
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Email</TableHead>
            <TableHead>Experience</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {applications.map((app) => (
            <TableRow key={app.id}>
              <TableCell>{app.email}</TableCell>
              <TableCell className="max-w-xs truncate">{app.description}</TableCell>
              <TableCell>
                <span className={`px-2 py-1 rounded-full text-sm ${
                  app.status === 'approved' 
                    ? 'bg-green-100 text-green-800' 
                    : app.status === 'rejected'
                    ? 'bg-red-100 text-red-800'
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {app.status}
                </span>
              </TableCell>
              <TableCell>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => updateApplicationStatus(app.id, 'approved')}
                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                    disabled={app.status !== 'pending'}
                  >
                    <CheckCircle className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => updateApplicationStatus(app.id, 'rejected')}
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                    disabled={app.status !== 'pending'}
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};