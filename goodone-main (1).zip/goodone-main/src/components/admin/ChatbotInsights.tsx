import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Brain } from "lucide-react";

const data = [
  { name: 'Week 1', responses: 240 },
  { name: 'Week 2', responses: 320 },
  { name: 'Week 3', responses: 280 },
  { name: 'Week 4', responses: 400 },
];

export const ChatbotInsights = () => {
  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2 bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
        <Brain className="w-6 h-6 text-hotbot-pink" />
        Chatbot Performance
      </h2>
      <div className="h-[300px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data}>
            <CartesianGrid strokeDasharray="3 3" className="opacity-50" />
            <XAxis dataKey="name" stroke="#666" />
            <YAxis stroke="#666" />
            <Tooltip 
              contentStyle={{ 
                background: 'rgba(255, 255, 255, 0.9)',
                border: '1px solid #FF5B93',
                borderRadius: '8px'
              }}
            />
            <Line 
              type="monotone" 
              dataKey="responses" 
              stroke="#FF5B93"
              strokeWidth={2}
              dot={{ fill: '#FF5B93', strokeWidth: 2 }}
              activeDot={{ r: 6, fill: '#A45DBF' }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};