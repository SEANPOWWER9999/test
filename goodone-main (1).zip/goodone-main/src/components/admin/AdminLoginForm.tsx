import { useState } from "react";
import { motion } from "framer-motion";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";

interface AdminLoginFormProps {
  onLogin: () => void;
}

export const AdminLoginForm = ({ onLogin }: AdminLoginFormProps) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { toast } = useToast();

  const handleAdminLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (username === "admin" && password === "x1122xXx") {
      onLogin();
      toast({
        title: "Welcome Admin! 👋",
        description: "Successfully logged in to admin dashboard",
      });
    } else {
      toast({
        title: "Access Denied ⚠️",
        description: "Invalid credentials or unauthorized access",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-pink-50 flex items-center justify-center px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full"
      >
        <div className="bg-white p-8 rounded-xl shadow-lg border border-pink-100">
          <div className="flex items-center gap-2 mb-6">
            <Shield className="w-8 h-8 text-hotbot-pink" />
            <h1 className="text-2xl font-bold text-gray-900">Admin Access Only</h1>
          </div>
          
          <p className="text-gray-600 mb-6">
            This is a restricted area for administrators only. Please enter your credentials to continue.
          </p>

          <form onSubmit={handleAdminLogin} className="space-y-4">
            <div>
              <Input
                type="text"
                placeholder="Admin Username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="bg-pink-50 border-pink-200 focus:border-pink-400"
              />
            </div>
            <div>
              <Input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-pink-50 border-pink-200 focus:border-pink-400"
              />
            </div>
            <Button 
              type="submit"
              className="w-full bg-gradient-hotbot text-white"
            >
              Login to Admin Dashboard
            </Button>
          </form>
        </div>
      </motion.div>
    </div>
  );
};