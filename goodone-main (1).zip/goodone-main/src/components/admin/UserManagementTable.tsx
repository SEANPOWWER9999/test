import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { UserCheck, UserX, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export const UserManagementTable = () => {
  const [users] = useState([
    { id: 1, name: "Sarah Smith", email: "sarah@example.com", status: "active" },
    { id: 2, name: "John Doe", email: "john@example.com", status: "inactive" },
    { id: 3, name: "Emma Wilson", email: "emma@example.com", status: "active" },
    { id: 4, name: "Michael Chen", email: "michael@example.com", status: "inactive" },
  ]);

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-xl font-bold bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
          User Management
        </h2>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search users..."
            className="pl-10 bg-pink-50 border-pink-200 focus:border-pink-400"
          />
        </div>
      </div>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Email</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {users.map((user) => (
            <TableRow key={user.id}>
              <TableCell className="font-medium">{user.name}</TableCell>
              <TableCell>{user.email}</TableCell>
              <TableCell>
                <span className={`px-2 py-1 rounded-full text-sm ${
                  user.status === 'active' 
                    ? 'bg-gradient-to-r from-green-100 to-green-200 text-green-800' 
                    : 'bg-gradient-to-r from-red-100 to-red-200 text-red-800'
                }`}>
                  {user.status}
                </span>
              </TableCell>
              <TableCell>
                <div className="flex gap-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-green-600 hover:text-green-800 hover:bg-green-50"
                  >
                    <UserCheck className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="text-red-600 hover:text-red-800 hover:bg-red-50"
                  >
                    <UserX className="w-4 h-4" />
                  </Button>
                </div>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};