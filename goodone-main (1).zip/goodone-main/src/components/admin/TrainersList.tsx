import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Users } from "lucide-react";

export const TrainersList = () => {
  const trainers = [
    { id: 1, name: "Emma Wilson", specialization: "Conversation Flow", activeScenarios: 15 },
    { id: 2, name: "Michael Chen", specialization: "Response Patterns", activeScenarios: 12 },
    { id: 3, name: "Sarah Johnson", specialization: "Personality Development", activeScenarios: 8 },
    { id: 4, name: "David Lee", specialization: "Language Adaptation", activeScenarios: 10 },
  ];

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <h2 className="text-xl font-bold mb-4 flex items-center gap-2 bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
        <Users className="w-6 h-6 text-hotbot-pink" />
        Active Trainers
      </h2>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Name</TableHead>
            <TableHead>Specialization</TableHead>
            <TableHead>Active Scenarios</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {trainers.map((trainer) => (
            <TableRow key={trainer.id}>
              <TableCell className="font-medium">{trainer.name}</TableCell>
              <TableCell>{trainer.specialization}</TableCell>
              <TableCell>
                <span className="px-2 py-1 rounded-full text-sm bg-gradient-to-r from-pink-100 to-purple-100 text-hotbot-purple">
                  {trainer.activeScenarios}
                </span>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
};