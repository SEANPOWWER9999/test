import { useEffect, useState } from "react";
import { Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type Application = {
  id: string;
  type: string;
  email: string;
  description: string;
  status: string;
  created_at: string;
  updated_at: string;
};

export const NotificationPanel = () => {
  const [applications, setApplications] = useState<Application[]>([]);

  useEffect(() => {
    // Fetch initial applications
    const fetchApplications = async () => {
      const { data } = await supabase
        .from("applications")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(5);

      if (data) {
        setApplications(data);
      }
    };

    fetchApplications();

    // Subscribe to new applications
    const channel = supabase
      .channel("applications")
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "applications",
        },
        (payload) => {
          setApplications((current) => [payload.new as Application, ...current].slice(0, 5));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const getTypeColor = (type: string) => {
    return type === "trainer" 
      ? "bg-gradient-to-r from-hotbot-pink to-hotbot-purple text-white"
      : "bg-gradient-to-r from-hotbot-coral to-hotbot-teal text-white";
  };

  return (
    <div className="bg-white/90 backdrop-blur-sm rounded-xl p-6 shadow-lg border border-pink-100">
      <h2 className="text-2xl font-bold mb-4 flex items-center gap-2 bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
        <Bell className="w-6 h-6 text-hotbot-pink" />
        Latest Applications
      </h2>
      <div className="space-y-4">
        {applications.map((application) => (
          <div
            key={application.id}
            className="p-4 rounded-lg bg-gradient-to-r from-pink-50 to-purple-50 hover:from-pink-100 hover:to-purple-100 
                     transition-colors duration-300 border border-pink-100"
          >
            <div className="flex justify-between items-start mb-2">
              <div className="space-y-1">
                <span className="text-sm font-medium text-gray-600">
                  {application.email}
                </span>
                <span className={`text-xs px-3 py-1 rounded-full ${getTypeColor(application.type)} 
                               shadow-sm border border-white/20`}>
                  {application.type}
                </span>
              </div>
              <span className="text-xs text-gray-500">
                {new Date(application.created_at).toLocaleDateString()}
              </span>
            </div>
            <p className="text-sm text-gray-600 line-clamp-2">
              {application.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};