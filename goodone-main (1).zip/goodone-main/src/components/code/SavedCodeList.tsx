import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { SavedCode } from "@/types/saved-code";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export const SavedCodeList = () => {
  const [codes, setCodes] = useState<SavedCode[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadSavedCodes();
  }, []);

  const loadSavedCodes = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('saved_codes')
        .select('*')
        .eq('user_id', user.id);

      if (error) throw error;
      setCodes(data as SavedCode[]);
    } catch (error: any) {
      toast({
        title: "Error loading saved codes",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleDelete = async (id: string) => {
    try {
      const { error } = await supabase
        .from('saved_codes')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setCodes(codes.filter(code => code.id !== id));
      toast({
        title: "Success",
        description: "Code deleted successfully",
      });
    } catch (error: any) {
      toast({
        title: "Error deleting code",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-4">
      {codes.map((code) => (
        <Card key={code.id} className="p-4 bg-white/90 backdrop-blur-sm hover:shadow-lg transition-all">
          <div className="flex justify-between items-start">
            <div>
              <h3 className="text-lg font-semibold text-hotbot-purple">{code.title}</h3>
              <p className="text-sm text-gray-500">{code.language}</p>
              <pre className="mt-2 p-4 bg-gray-50 rounded-lg overflow-x-auto">
                <code>{code.code}</code>
              </pre>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={() => handleDelete(code.id)}
              className="ml-4"
            >
              Delete
            </Button>
          </div>
        </Card>
      ))}
      {codes.length === 0 && (
        <p className="text-center text-gray-500">No saved codes yet</p>
      )}
    </div>
  );
};