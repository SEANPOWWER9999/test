import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Star } from "lucide-react";

interface WelcomeDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const WelcomeDialog = ({ open, onOpenChange }: WelcomeDialogProps) => {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-gradient-to-br from-white to-pink-50 border-2 border-pink-200">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center text-gradient">
            Coming Soon! 🎉
          </DialogTitle>
        </DialogHeader>
        <div className="space-y-4 text-center">
          <p className="text-lg text-gray-700">
            HOTBOT is your ultimate AI companion for managing client communications.
            We're revolutionizing the way professionals interact with their clients
            through intelligent automation and personalized responses.
          </p>
          <p className="text-sm text-hotbot-purple">
            We're currently seeking talented bot trainers and passionate investors
            to join our mission. Apply below to be part of this exciting journey! ✨
          </p>
          <div className="mt-4 p-4 bg-gradient-to-r from-hotbot-gold/10 to-hotbot-yellow/10 rounded-xl border border-hotbot-gold/20">
            <h3 className="text-lg font-bold text-hotbot-gold mb-2">🌟 Limited Time Offer!</h3>
            <p className="text-sm text-gray-600">
              Secure your early bird spot for just $10 and get guaranteed access
              when we launch, plus exclusive perks and benefits!
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};