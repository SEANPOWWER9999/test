import { motion } from "framer-motion";
import { Sparkles, Shield, Rocket } from "lucide-react";

const features = [
  {
    icon: Sparkles,
    title: "Smart Automation",
    description: "Let HOTBOT handle your client messages 24/7, keeping them engaged while you focus on what matters."
  },
  {
    icon: Shield,
    title: "Privacy First",
    description: "Your data is encrypted and secure. We never share your information with third parties."
  },
  {
    icon: Rocket,
    title: "Boost Your Income",
    description: "Maximize your earnings with smart client management and automated responses."
  }
];

export const FeatureCards = () => (
  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
    {features.map((feature, index) => (
      <motion.div
        key={feature.title}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: index * 0.2 }}
        className="bg-white/90 backdrop-blur-sm p-6 rounded-2xl shadow-lg border-2 border-pink-100 hover:border-hotbot-pink/50 transition-all duration-300"
      >
        <div className="flex items-center justify-center mb-4">
          <feature.icon className="w-8 h-8 text-hotbot-pink" />
        </div>
        <h3 className="text-xl font-semibold text-gray-800 mb-3">{feature.title}</h3>
        <p className="text-gray-600">{feature.description}</p>
      </motion.div>
    ))}
  </div>
);