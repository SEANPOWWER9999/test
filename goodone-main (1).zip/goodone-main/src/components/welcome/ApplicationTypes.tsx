import { Button } from "@/components/ui/button";
import { GraduationCap, Crown, Star } from "lucide-react";

type ApplicationType = "trainer" | "investor" | "early-bird";

interface ApplicationTypesProps {
  selectedType: ApplicationType;
  onTypeSelect: (type: ApplicationType) => void;
}

export const ApplicationTypes = ({ selectedType, onTypeSelect }: ApplicationTypesProps) => (
  <div className="w-full max-w-5xl mx-auto py-12">
    <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent">
      Choose Your Path to Success
    </h2>
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8 px-4 md:px-6">
      <ApplicationTypeButton
        type="trainer"
        icon={GraduationCap}
        title="Bot Trainer 🤖"
        description="Help shape the future of AI communication"
        isSelected={selectedType === "trainer"}
        onClick={() => onTypeSelect("trainer")}
      />
      <ApplicationTypeButton
        type="investor"
        icon={Crown}
        title="Investor 💎"
        description="Be part of our growth journey"
        isSelected={selectedType === "investor"}
        onClick={() => onTypeSelect("investor")}
      />
      <ApplicationTypeButton
        type="early-bird"
        icon={Star}
        title="Early Bird 🐥"
        description="Secure your spot for just $10"
        isSelected={selectedType === "early-bird"}
        onClick={() => onTypeSelect("early-bird")}
      />
    </div>
  </div>
);

interface ApplicationTypeButtonProps {
  type: ApplicationType;
  icon: React.ElementType;
  title: string;
  description: string;
  isSelected: boolean;
  onClick: () => void;
}

const ApplicationTypeButton = ({
  type,
  icon: Icon,
  title,
  description,
  isSelected,
  onClick
}: ApplicationTypeButtonProps) => (
  <Button
    type="button"
    variant={isSelected ? "default" : "outline"}
    onClick={onClick}
    className={`relative w-full min-h-[240px] p-8 flex flex-col items-center justify-center gap-6 transition-all duration-300 
      ${isSelected 
        ? type === "early-bird"
          ? "bg-gradient-to-br from-hotbot-gold via-hotbot-yellow to-hotbot-gold hover:from-hotbot-coral hover:to-hotbot-red"
          : "bg-gradient-to-br from-hotbot-pink via-hotbot-purple to-hotbot-pink hover:from-hotbot-coral hover:to-hotbot-red"
        : "hover:border-hotbot-pink hover:shadow-xl hover:scale-105 bg-white/95"
      }
      ${!isSelected && "border-2"}
      rounded-2xl overflow-hidden backdrop-blur-sm`}
  >
    <div className="flex flex-col items-center space-y-4 relative z-10">
      <Icon className={`w-16 h-16 mb-4 transition-transform duration-300 ${!isSelected && "text-hotbot-pink"}`} />
      <h3 className="text-2xl font-bold">{title}</h3>
      <p className="text-base text-center opacity-90 max-w-[200px] leading-relaxed">
        {description}
      </p>
    </div>
    {!isSelected && (
      <div className="absolute inset-0 bg-gradient-to-br from-transparent via-transparent to-pink-50/30" />
    )}
  </Button>
);