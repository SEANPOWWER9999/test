import { Star } from "lucide-react";

export const EarlyBirdPerks = () => (
  <div className="p-6 bg-gradient-to-r from-hotbot-gold/10 to-hotbot-yellow/10 rounded-xl border border-hotbot-gold/20 space-y-4">
    <h3 className="text-xl font-bold text-hotbot-gold mb-4">Early Bird Perks! 🌟</h3>
    <ul className="space-y-3 text-gray-700">
      <li className="flex items-center gap-2">
        <Star className="w-4 h-4 text-hotbot-gold flex-shrink-0" />
        <span>Guaranteed access to premium features at launch</span>
      </li>
      <li className="flex items-center gap-2">
        <Star className="w-4 h-4 text-hotbot-gold flex-shrink-0" />
        <span>Priority customer support</span>
      </li>
      <li className="flex items-center gap-2">
        <Star className="w-4 h-4 text-hotbot-gold flex-shrink-0" />
        <span>Exclusive early access to new features</span>
      </li>
      <li className="flex items-center gap-2">
        <Star className="w-4 h-4 text-hotbot-gold flex-shrink-0" />
        <span>Special member-only events and training</span>
      </li>
    </ul>
    <div className="mt-4 p-4 bg-white/50 rounded-lg">
      <p className="text-sm text-gray-600 mb-2">
        Secure your spot now for just $10! Limited availability.
      </p>
      <div className="flex items-center gap-2 text-sm text-hotbot-gold font-medium">
        <Star className="w-4 h-4" />
        <span>Only a few spots remaining!</span>
      </div>
    </div>
  </div>
);