import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

export const HeroSection = () => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="text-center mb-12 max-w-4xl mx-auto"
  >
    <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent mb-6">
      Join the HOTBOT Revolution! ✨
    </h1>
    <p className="text-lg md:text-xl text-gray-700 mb-8 max-w-2xl mx-auto">
      Transform your online presence with AI-powered automation that keeps your audience engaged 24/7.
      Be part of the future of digital communication!
    </p>
    <div className="inline-block">
      <Sparkles className="w-8 h-8 text-hotbot-gold animate-pulse mx-auto" />
    </div>
  </motion.div>
);