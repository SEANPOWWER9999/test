import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { generateBTCAddress } from "@/lib/payment";
import { ApplicationTypes } from "./ApplicationTypes";
import { EarlyBirdPerks } from "./EarlyBirdPerks";

export const ApplicationForm = () => {
  const [email, setEmail] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState<"trainer" | "investor" | "early-bird">("trainer");
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (type === "early-bird") {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
          toast({
            title: "Please sign in first",
            description: "You need to be signed in to reserve an early bird spot.",
            variant: "destructive",
          });
          return;
        }

        const btcData = await generateBTCAddress(10);
        
        const { error: depositError } = await supabase
          .from("btc_deposits")
          .insert([{
            user_id: user.id,
            amount: 10,
            btc_address: btcData.address
          }]);

        if (depositError) throw depositError;

        toast({
          title: "Early Bird Spot Reserved! 🎉",
          description: "Please complete the payment to secure your spot.",
        });
        return;
      }

      const { error } = await supabase
        .from("applications")
        .insert([{ email, description, type }]);

      if (error) throw error;

      toast({
        title: "Application Submitted! 🎉",
        description: "We'll review your application and get back to you soon.",
      });

      setEmail("");
      setDescription("");
    } catch (error: any) {
      toast({
        title: "Oops! Something went wrong 😅",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <ApplicationTypes selectedType={type} onTypeSelect={setType} />

      {type !== "early-bird" ? (
        <div className="space-y-4">
          <Input
            type="email"
            placeholder="Your Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="bg-white/50 border-2 border-pink-200 focus:border-hotbot-gold transition-all duration-300"
          />

          <Textarea
            placeholder={
              type === "trainer"
                ? "Tell us about your experience in AI, chatbots, or customer service. What unique perspective can you bring to our training team?"
                : "Share your investment background and what excites you about HOTBOT's potential. What value can you add beyond capital?"
            }
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            required
            className="bg-white/50 border-2 border-pink-200 focus:border-hotbot-gold transition-all duration-300 min-h-[120px]"
          />
        </div>
      ) : (
        <EarlyBirdPerks />
      )}

      <Button 
        type="submit" 
        className={`w-full py-4 text-lg font-semibold ${
          type === "early-bird"
            ? "bg-gradient-to-r from-hotbot-gold to-hotbot-yellow hover:from-hotbot-coral hover:to-hotbot-red"
            : "bg-gradient-to-r from-hotbot-pink to-hotbot-purple hover:from-hotbot-coral hover:to-hotbot-red"
        } transition-all duration-300`}
      >
        {type === "early-bird" ? "Reserve My Spot ($10) ⭐" : "Submit Application ✨"}
      </Button>
    </form>
  );
};