import { motion } from "framer-motion";
import { Sparkles, Star, Shield, Rocket } from "lucide-react";

export const WelcomeMessage = () => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    className="text-center mb-8 space-y-6"
  >
    <div className="p-6 bg-gradient-to-r from-pink-100 to-purple-100 rounded-2xl">
      <h1 className="text-3xl font-bold bg-gradient-to-r from-pink-500 to-purple-500 bg-clip-text text-transparent mb-4">
        Time to Shine, Gorgeous! ✨
      </h1>
      <p className="text-gray-700 text-lg mb-6">
        The HOTBOT is your perfect BFF—always ready to keep your secrets, 
        hype you up, and make sure you're all about the PAPER. No games, just results! 💁‍♀️
      </p>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
        <div className="bg-white/80 p-4 rounded-xl shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center mb-2">
            <Sparkles className="w-6 h-6 text-hotbot-pink" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Smart Automation</h3>
          <p className="text-gray-600">
            Let HOTBOT handle your client messages 24/7, keeping them engaged while you focus on what matters.
          </p>
        </div>

        <div className="bg-white/80 p-4 rounded-xl shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center mb-2">
            <Shield className="w-6 h-6 text-hotbot-purple" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Privacy First</h3>
          <p className="text-gray-600">
            Your data is encrypted and secure. We never share your information with third parties.
          </p>
        </div>

        <div className="bg-white/80 p-4 rounded-xl shadow-sm hover:shadow-md transition-shadow">
          <div className="flex items-center justify-center mb-2">
            <Rocket className="w-6 h-6 text-hotbot-coral" />
          </div>
          <h3 className="font-semibold text-lg mb-2">Boost Your Income</h3>
          <p className="text-gray-600">
            Maximize your earnings with smart client management and automated responses.
          </p>
        </div>
      </div>
    </div>

    <div className="bg-gradient-to-r from-hotbot-gold/10 to-hotbot-yellow/10 p-6 rounded-2xl border border-hotbot-gold/20">
      <div className="flex items-center justify-center mb-4">
        <Star className="w-8 h-8 text-hotbot-gold animate-pulse" />
      </div>
      <h2 className="text-xl font-semibold text-hotbot-gold mb-2">
        Limited Time Opportunity!
      </h2>
      <p className="text-gray-700">
        Join our exclusive early access program and get premium features, priority support, 
        and special perks when we launch. Only a few spots remaining!
      </p>
    </div>
  </motion.div>
);