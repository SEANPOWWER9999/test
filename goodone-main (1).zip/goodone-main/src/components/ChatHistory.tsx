import { ChatMessage } from "@/types/chat";

interface ChatHistoryProps {
  messages: ChatMessage[];
}

const ChatHistory = ({ messages }: ChatHistoryProps) => {
  return (
    <div className="space-y-4 max-h-[400px] overflow-y-auto p-4">
      {messages.map((message, index) => (
        <div
          key={index}
          className={`flex ${
            message.role === "escort" ? "justify-end" : "justify-start"
          }`}
        >
          <div
            className={`rounded-lg px-4 py-2 max-w-[80%] ${
              message.role === "escort"
                ? "bg-primary text-primary-foreground"
                : "bg-muted"
            }`}
          >
            <p className="text-sm">{message.content}</p>
            <span className="text-xs opacity-70">
              {new Date(message.timestamp).toLocaleTimeString()}
            </span>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ChatHistory;