import { Button } from "@/components/ui/button";
import { ThumbsDown } from "lucide-react";

interface FeedbackButtonProps {
  onFeedback: () => void;
}

const FeedbackButton = ({ onFeedback }: FeedbackButtonProps) => {
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={onFeedback}
      className="text-red-600 hover:text-red-800 hover:bg-red-50"
    >
      <ThumbsDown className="h-4 w-4 mr-2" />
      Mark Incorrect
    </Button>
  );
};

export default FeedbackButton;