import { useState } from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { generateBTCAddress } from "@/lib/payment";
import { Heart, Star, Crown } from "lucide-react";
import { useNavigate } from "react-router-dom";

const PatronPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const tiers = [
    {
      name: "Supporter",
      amount: 5,
      reward: 10,
      icon: Heart,
      description: "Early supporter special: $5 now = $10 credit at launch!"
    },
    {
      name: "Champion",
      amount: 10,
      reward: 20,
      icon: Star,
      description: "Champion tier: $10 now = $20 credit at launch!"
    },
    {
      name: "Angel",
      amount: 20,
      reward: 40,
      icon: Crown,
      description: "Angel patron: $20 now = $40 credit at launch!"
    }
  ];

  const handleDonation = async (amount: number) => {
    try {
      const data = await generateBTCAddress(amount);
      
      toast({
        title: "Thank you for your support! 💖",
        description: "Check your email for payment instructions.",
      });
      
      navigate("/payment-confirmation");
    } catch (error: any) {
      toast({
        title: "Error processing donation",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-12"
        >
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Become an Early Patron 👑
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Support our development and get <span className="font-bold text-hotbot-pink">DOUBLE CREDIT</span> when we launch! 
            Your contribution helps us build a better solution for everyone.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {tiers.map((tier) => (
            <motion.div
              key={tier.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              whileHover={{ scale: 1.05 }}
              transition={{ duration: 0.2 }}
            >
              <Card className="relative overflow-hidden border-2 hover:border-hotbot-pink transition-all duration-300">
                <CardHeader className="text-center pb-2">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-r from-hotbot-pink to-hotbot-purple rounded-full flex items-center justify-center">
                    <tier.icon className="w-8 h-8 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold">{tier.name}</CardTitle>
                </CardHeader>
                <CardContent className="text-center space-y-4">
                  <div className="text-4xl font-bold text-hotbot-pink">
                    ${tier.amount}
                  </div>
                  <div className="text-sm text-gray-600">
                    {tier.description}
                  </div>
                  <Button 
                    onClick={() => handleDonation(tier.amount)}
                    className="w-full bg-gradient-to-r from-hotbot-pink to-hotbot-purple hover:from-hotbot-pink/90 hover:to-hotbot-purple/90"
                  >
                    Donate Now
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
          className="mt-12 text-center text-gray-600"
        >
          <p className="mb-2">Your support helps us build:</p>
          <ul className="text-sm space-y-2">
            <li>✨ Better AI Training</li>
            <li>🚀 Faster Servers</li>
            <li>💎 Premium Features</li>
            <li>🛡️ Enhanced Security</li>
          </ul>
        </motion.div>
      </div>
    </div>
  );
};

export default PatronPage;