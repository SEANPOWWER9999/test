import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { PersonaSettings } from "@/components/profile/PersonaSettings";
import { ProfileForm } from "@/components/profile/ProfileForm";
import { HttpSmsSection } from "@/components/profile/HttpSmsSection";
import { SavedCodeList } from "@/components/code/SavedCodeList";
import { ProfileSetup } from "@/components/profile/ProfileSetup";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useProfileData } from "@/hooks/useProfileData";
import { useToast } from "@/hooks/use-toast";

const Profile = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [userId, setUserId] = useState<string | undefined>();
  const { profile, setProfile, isLoading } = useProfileData(userId);

  useEffect(() => {
    checkAuth();
  }, []);

  const checkAuth = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) {
      navigate('/login');
    } else {
      setUserId(user.id);
    }
  };

  const handleProfileSave = async (updatedProfile: any) => {
    try {
      const { error } = await supabase
        .from('profile_settings')
        .update(updatedProfile)
        .eq('user_id', userId);

      if (error) throw error;

      toast({
        title: "Success",
        description: "Profile updated successfully",
      });
      
      if (setProfile) {
        setProfile(updatedProfile);
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleBack = () => {
    navigate(-1);
  };

  if (isLoading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto p-4 space-y-8 min-h-screen bg-gradient-to-br from-pink-50 to-purple-50">
      <Tabs defaultValue="setup" className="space-y-6">
        <TabsList className="grid grid-cols-5 gap-4">
          <TabsTrigger value="setup">Profile Setup</TabsTrigger>
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="persona">Persona</TabsTrigger>
          <TabsTrigger value="sms">SMS Settings</TabsTrigger>
          <TabsTrigger value="saved">Saved Codes</TabsTrigger>
        </TabsList>

        <TabsContent value="setup">
          <ProfileSetup />
        </TabsContent>

        <TabsContent value="profile">
          {profile && (
            <ProfileForm 
              profile={profile} 
              onSave={handleProfileSave}
              onBack={handleBack}
            />
          )}
        </TabsContent>

        <TabsContent value="persona">
          <PersonaSettings />
        </TabsContent>

        <TabsContent value="sms">
          <HttpSmsSection />
        </TabsContent>

        <TabsContent value="saved">
          <div className="mt-8">
            <h2 className="text-xl font-semibold mb-4 text-hotbot-purple">Saved Responses</h2>
            <SavedCodeList />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Profile;