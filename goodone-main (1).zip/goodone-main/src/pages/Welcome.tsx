import { useState } from "react";
import { Link } from "react-router-dom";
import { Crown, GraduationCap } from "lucide-react";
import { motion } from "framer-motion"; // Added this import
import { Button } from "@/components/ui/button";
import { ApplicationForm } from "@/components/welcome/ApplicationForm";
import { WelcomeDialog } from "@/components/welcome/WelcomeDialog";
import { HeroSection } from "@/components/welcome/HeroSection";
import { FeatureCards } from "@/components/welcome/FeatureCards";

const Welcome = () => {
  const [showDialog, setShowDialog] = useState(true);

  return (
    <div className="min-h-screen relative overflow-hidden bg-gradient-to-br from-hotbot-pink via-hotbot-purple to-hotbot-coral">
      <div className="absolute inset-0 opacity-10">
        <div className="absolute inset-0 bg-[url('/photo-1721322800607-8c38375eef04')] bg-cover bg-center animate-pulse" />
        <div className="absolute inset-0 bg-gradient-to-r from-hotbot-yellow/20 to-hotbot-gold/20" />
      </div>
      
      <div className="relative z-10 container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          <HeroSection />
          <FeatureCards />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white/90 backdrop-blur-md p-8 rounded-2xl shadow-xl
                       border-2 border-white/50 hover:border-hotbot-gold/50 transition-all duration-300"
          >
            <ApplicationForm />

            <div className="mt-8 pt-6 border-t border-pink-200">
              <div className="flex justify-center gap-4">
                <Button 
                  asChild 
                  variant="ghost" 
                  className="text-hotbot-purple hover:bg-hotbot-purple/10 transition-all duration-300"
                >
                  <Link to="/admin" className="flex items-center gap-2">
                    <Crown className="w-4 h-4" /> Admin Login
                  </Link>
                </Button>
                <Button 
                  asChild 
                  variant="ghost" 
                  className="text-hotbot-pink hover:bg-hotbot-pink/10 transition-all duration-300"
                >
                  <Link to="/trainer/dashboard" className="flex items-center gap-2">
                    <GraduationCap className="w-4 h-4" /> Trainer Login
                  </Link>
                </Button>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      <WelcomeDialog open={showDialog} onOpenChange={setShowDialog} />
    </div>
  );
};

export default Welcome;