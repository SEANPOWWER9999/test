import { useState } from "react";
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Repeat, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import FeedbackButton from "@/components/FeedbackButton";
import ChatHistory from "@/components/ChatHistory";
import UserSettings from "@/components/UserSettings";
import { getModelResponse } from "@/services/huggingface";
import { useChatState } from "@/hooks/useChatState";
import { ChatMessage, Role } from "@/types/chat";

const TrainerDashboard = () => {
  const navigate = useNavigate();
  const { toast } = useToast();
  const { 
    isEscortMode, 
    messages,
    settings,
    userData,
    handleUserDataChange,
    handleRoleToggle,
    setMessages 
  } = useChatState();

  const [inputMessage, setInputMessage] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const handleSendMessage = async () => {
    if (!inputMessage.trim()) return;

    setIsLoading(true);
    const userRole: Role = isEscortMode ? "escort" : "client";
    const botRole: Role = isEscortMode ? "client" : "escort";

    const userMessage: ChatMessage = {
      role: userRole,
      content: inputMessage,
      timestamp: Date.now(),
    };

    setMessages([...messages, userMessage]);
    setInputMessage("");

    try {
      const botResponse = await getModelResponse(inputMessage, settings);
      const botMessage: ChatMessage = {
        role: botRole,
        content: botResponse,
        timestamp: Date.now(),
      };
      setMessages([...messages, userMessage, botMessage]);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to get response. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container py-8 space-y-8">
        <div className="flex items-center gap-4">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => navigate(-1)}
            className="hover:bg-pink-100"
          >
            <ArrowLeft className="w-5 h-5 text-hotbot-pink" />
          </Button>
          <h1 className="text-4xl font-bold text-center bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
            Trainer Dashboard
          </h1>
        </div>

        <div className="max-w-4xl mx-auto space-y-8">
          <UserSettings 
            userData={userData}
            onUserDataChange={handleUserDataChange}
          />

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <Switch
                  id="role-mode"
                  checked={isEscortMode}
                  onCheckedChange={handleRoleToggle}
                />
                <Label htmlFor="role-mode">
                  {isEscortMode ? "Escort Mode" : "Client Mode"}
                </Label>
              </div>
              <Button
                variant="outline"
                size="icon"
                onClick={handleRoleToggle}
                title="Switch Role"
              >
                <Repeat className="h-4 w-4" />
              </Button>
            </div>
            <FeedbackButton onFeedback={() => {
              toast({
                title: "Feedback recorded",
                description: "The response has been marked as incorrect and will be used for training.",
              });
            }} />
          </div>

          <div className="border rounded-lg">
            <ChatHistory messages={messages} />
            <div className="border-t p-4 flex gap-4">
              <input
                className="flex-1 px-4 py-2 border rounded-lg"
                placeholder="Type your message..."
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                disabled={isLoading}
              />
              <Button onClick={handleSendMessage} disabled={isLoading}>
                {isLoading ? "Sending..." : "Send"}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TrainerDashboard;