import { motion } from "framer-motion";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { MessageCircle, Mail, Phone } from "lucide-react";

const Help = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center space-y-4"
        >
          <h1 className="text-4xl font-bold text-gradient">Help & Support</h1>
          <p className="text-xl text-gray-600">How can we assist you today?</p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          <Button variant="outline" className="p-8 h-auto flex flex-col gap-4">
            <MessageCircle className="w-8 h-8 text-hotbot-pink" />
            <span className="text-lg font-semibold">Live Chat</span>
            <span className="text-sm text-gray-500">Chat with our support team</span>
          </Button>
          
          <Button variant="outline" className="p-8 h-auto flex flex-col gap-4">
            <Mail className="w-8 h-8 text-hotbot-purple" />
            <span className="text-lg font-semibold">Email Support</span>
            <span className="text-sm text-gray-500">support@hotbot.ai</span>
          </Button>
          
          <Button variant="outline" className="p-8 h-auto flex flex-col gap-4">
            <Phone className="w-8 h-8 text-hotbot-teal" />
            <span className="text-lg font-semibold">Phone Support</span>
            <span className="text-sm text-gray-500">Available 24/7</span>
          </Button>
        </div>

        <Accordion type="single" collapsible className="bg-white rounded-xl shadow-lg p-6">
          <AccordionItem value="item-1">
            <AccordionTrigger>How do I get started with HotBot?</AccordionTrigger>
            <AccordionContent>
              Sign up for an account, complete your profile, and start using our AI-powered features to enhance your communication.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-2">
            <AccordionTrigger>What payment methods do you accept?</AccordionTrigger>
            <AccordionContent>
              We accept all major credit cards, PayPal, and cryptocurrency payments including Bitcoin.
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-3">
            <AccordionTrigger>Is my data secure?</AccordionTrigger>
            <AccordionContent>
              Yes, we use industry-standard encryption and security measures to protect your data. Your privacy is our top priority.
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </div>
  );
};

export default Help;