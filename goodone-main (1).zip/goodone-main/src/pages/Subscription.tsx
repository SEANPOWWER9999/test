import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Zap } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { generateBTCAddress } from "@/lib/payment";

const SubscriptionPage = () => {
  const navigate = useNavigate();
  const { toast } = useToast();

  const plans = [
    {
      name: "Free",
      price: "$0",
      description: "Perfect for trying out HotBot",
      features: [
        "50 messages per month",
        "Basic bot customization",
        "Email support",
        "Single phone number"
      ],
      limit: 50,
      action: "Current Plan",
      isPopular: false
    },
    {
      name: "Pro",
      price: "$29.99",
      description: "Best for growing businesses",
      features: [
        "1000 messages per month",
        "Advanced bot customization",
        "Priority support",
        "Multiple phone numbers",
        "Analytics dashboard",
        "Custom webhooks"
      ],
      limit: 1000,
      action: "Upgrade",
      isPopular: true
    },
    {
      name: "Enterprise",
      price: "$99.99",
      description: "For power users and agencies",
      features: [
        "Unlimited messages",
        "White-label solution",
        "24/7 phone support",
        "Unlimited phone numbers",
        "Advanced analytics",
        "Custom integrations",
        "Dedicated account manager"
      ],
      limit: -1,
      action: "Contact Sales",
      isPopular: false
    }
  ];

  const handleSubscribe = async (planName: string) => {
    if (planName === "Free") {
      toast({
        title: "Already on Free Plan",
        description: "You're currently using the free plan.",
      });
      return;
    }

    try {
      // For this example, we'll use BTC payment for subscription
      const amount = planName === "Pro" ? 29.99 : 99.99;
      const data = await generateBTCAddress(amount);
      
      toast({
        title: "Payment Processing",
        description: "Please check your email for payment instructions.",
      });
      
      // Redirect to payment confirmation page (you'll need to create this)
      navigate("/payment-confirmation");
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
          <p className="text-xl text-gray-600">
            Scale your automation with our flexible pricing plans
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mt-8">
          {plans.map((plan) => (
            <Card 
              key={plan.name}
              className={`relative ${
                plan.isPopular ? 'border-hotbot-pink shadow-lg scale-105' : 'border-gray-200'
              }`}
            >
              {plan.isPopular && (
                <Badge 
                  className="absolute -top-3 left-1/2 -translate-x-1/2 bg-gradient-to-r from-hotbot-pink to-hotbot-purple"
                >
                  Most Popular
                </Badge>
              )}
              
              <CardHeader>
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <CardDescription className="text-lg">{plan.description}</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold">{plan.price}</span>
                  <span className="text-gray-600">/month</span>
                </div>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2">
                      <Check className="h-5 w-5 text-hotbot-pink" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>

              <CardFooter>
                <Button 
                  className={`w-full ${
                    plan.isPopular 
                      ? 'bg-gradient-to-r from-hotbot-pink to-hotbot-purple hover:from-hotbot-pink/90 hover:to-hotbot-purple/90'
                      : ''
                  }`}
                  variant={plan.isPopular ? 'default' : 'outline'}
                  onClick={() => handleSubscribe(plan.name)}
                >
                  {plan.action}
                  {plan.isPopular && <Zap className="ml-2 h-4 w-4" />}
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center text-gray-600">
          <p>All plans include our core features and 24/7 support</p>
          <p className="mt-2">Need a custom plan? <Button variant="link" className="text-hotbot-pink p-0">Contact us</Button></p>
        </div>
      </div>
    </div>
  );
};

export default SubscriptionPage;