import { SavedCodeList } from "@/components/code/SavedCodeList";

const SavedCode = () => {
  return (
    <div className="container py-8">
      <SavedCodeList />
    </div>
  );
};

export default SavedCode;