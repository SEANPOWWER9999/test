import { motion } from "framer-motion";
import { AddTrainerForm } from "@/components/admin/trainer-portal/AddTrainerForm";
import { TrainerApplicationList } from "@/components/admin/trainer-portal/TrainerApplicationList";

const TrainerPortal = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-pink-50 p-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-7xl mx-auto space-y-8"
      >
        <h1 className="text-3xl font-bold bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
          Trainer Management Portal
        </h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <AddTrainerForm />
          <TrainerApplicationList />
        </div>
      </motion.div>
    </div>
  );
};

export default TrainerPortal;