import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Training = () => {
  const navigate = useNavigate();

  useEffect(() => {
    navigate("/trainer/login");
  }, [navigate]);

  return null;
};

export default Training;