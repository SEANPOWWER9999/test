import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Users, Brain, BarChart3, Shield, ArrowLeft, UserPlus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AdminMetricsCard } from "@/components/admin/AdminMetricsCard";
import { UserManagementTable } from "@/components/admin/UserManagementTable";
import { TrainersList } from "@/components/admin/TrainersList";
import { ChatbotInsights } from "@/components/admin/ChatbotInsights";
import { NotificationPanel } from "@/components/admin/NotificationPanel";

const AdminDashboard = () => {
  const navigate = useNavigate();
  const [metrics, setMetrics] = useState({
    totalUsers: 0,
    activeTrainers: 0,
    totalConversations: 0,
    averageAccuracy: 0,
  });

  useEffect(() => {
    const fetchMetrics = async () => {
      const { count: usersCount } = await supabase
        .from("user_settings")
        .select("*", { count: "exact", head: true });

      const { count: trainersCount } = await supabase
        .from("personas")
        .select("*", { count: "exact", head: true });

      const { count: conversationsCount } = await supabase
        .from("conversations")
        .select("*", { count: "exact", head: true });

      setMetrics({
        totalUsers: usersCount || 0,
        activeTrainers: trainersCount || 0,
        totalConversations: conversationsCount || 0,
        averageAccuracy: 92, // Placeholder for now
      });
    };

    fetchMetrics();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-pink-50">
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <div className="flex justify-between items-center">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => navigate(-1)}
                className="hover:bg-pink-100"
              >
                <ArrowLeft className="w-5 h-5 text-hotbot-pink" />
              </Button>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-hotbot-pink to-hotbot-purple bg-clip-text text-transparent">
                Admin Dashboard
              </h1>
            </div>
            <div className="flex gap-4">
              <Button
                onClick={() => navigate("/admin/trainers")}
                className="bg-gradient-hotbot text-white flex items-center gap-2"
              >
                <UserPlus className="w-4 h-4" />
                Manage Trainers
              </Button>
              <Button
                onClick={() => navigate("/trainer/login")}
                className="bg-gradient-hotbot text-white"
              >
                Training Portal
              </Button>
              <Button
                onClick={() => navigate("/admin/login")}
                variant="outline"
                className="border-hotbot-pink text-hotbot-pink hover:bg-pink-50"
              >
                Logout
              </Button>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <AdminMetricsCard
              title="Total Users"
              value={metrics.totalUsers}
              icon={Users}
              trend="+12%"
            />
            <AdminMetricsCard
              title="Active Trainers"
              value={metrics.activeTrainers}
              icon={Brain}
              trend="+5%"
            />
            <AdminMetricsCard
              title="Total Conversations"
              value={metrics.totalConversations}
              icon={BarChart3}
              trend="+28%"
            />
            <AdminMetricsCard
              title="Response Accuracy"
              value={`${metrics.averageAccuracy}%`}
              icon={Shield}
              trend="+3%"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <UserManagementTable />
            </div>
            <div>
              <NotificationPanel />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <TrainersList />
            <ChatbotInsights />
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AdminDashboard;