import { WelcomeMessage } from "@/components/signup/WelcomeMessage";
import { LoginForm } from "@/components/login/LoginForm";
import { Features } from "@/components/signup/Features";
import { Link } from "react-router-dom";

const Login = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-purple-50 to-white p-4 md:p-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <WelcomeMessage />
        <LoginForm />
        <div className="text-center">
          <p className="text-gray-600">
            Don't have an account yet?{" "}
            <Link 
              to="/signup" 
              className="text-pink-500 hover:text-pink-600 font-semibold transition-colors"
            >
              Sign up here! ✨
            </Link>
          </p>
        </div>
        <Features />
      </div>
    </div>
  );
};

export default Login;