import { supabase } from "@/integrations/supabase/client";

interface ChatSettings {
  temperature: number;
  maxTokens: number; 
  topP: number;
  repetitionPenalty: number;
}

export const initializeChat = async (userId: string) => {
  try {
    console.log("Initializing chat for user:", userId);
    
    // Get user's chat settings
    const { data: settings, error: settingsError } = await supabase
      .from('chat_settings')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (settingsError) throw settingsError;

    // Transform the settings to match the ChatSettings interface
    const chatSettings: ChatSettings = {
      temperature: settings.temperature,
      maxTokens: settings.max_tokens,
      topP: settings.top_p,
      repetitionPenalty: settings.repetition_penalty
    };

    console.log("Chat settings loaded:", chatSettings);
    
    // Create a new chat session
    const { data: session, error: sessionError } = await supabase
      .from('chat_sessions')
      .insert([
        { user_id: userId }
      ])
      .select()
      .single();

    if (sessionError) throw sessionError;

    console.log("Chat session created:", session);

    return {
      sessionId: session.id,
      settings: chatSettings
    };
  } catch (error) {
    console.error("Error initializing chat:", error);
    throw error;
  }
};

export const sendMessage = async (sessionId: string, content: string, role: string) => {
  try {
    console.log("Sending message:", { sessionId, content, role });
    
    const { data, error } = await supabase
      .from('chat_messages')
      .insert([
        {
          session_id: sessionId,
          content,
          role,
          timestamp: Date.now()
        }
      ])
      .select()
      .single();

    if (error) throw error;

    console.log("Message sent successfully:", data);
    return data;
  } catch (error) {
    console.error("Error sending message:", error);
    throw error;
  }
};